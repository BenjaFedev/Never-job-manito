# Never Job Manito! — Android

Juego incluido en `app/src/main/assets`, presentado en una actividad Android horizontal. Funciona sin conexión.

## Compilar en GitHub

1. Creá un repositorio nuevo en GitHub, con rama principal `main`.
2. Descomprimí este ZIP y subí **el contenido de la carpeta** `Never-Job-Manito-Android` a la raíz del repositorio. La carpeta `.github/workflows` también debe subirse. Si usás Git, corré `git add -A`, `git commit -m "Agregar juego Android"` y `git push origin main`.
3. Abrí la pestaña **Actions** y seleccioná **Compilar APK**. El envío a `main` lo ejecuta automáticamente. También podés pulsar **Run workflow**.
4. Esperá el resultado verde. Abrí esa ejecución, bajá el artefacto **Never-Job-Manito-APK**, descomprimilo e instalá `app-debug.apk` en el teléfono.

Al ser un APK de depuración sirve para probar y regalar directamente. Android puede pedir permiso para instalar apps desde el navegador o gestor de archivos. Para publicar en Play Store se necesita un paquete de lanzamiento firmado.
